# For Ari ♡

A small romantic, interactive website asking Ari for a third date on Wednesday.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository and upload `index.html` (and this README).
2. Open **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. After publishing, GitHub will show the public website URL in the Pages section.
